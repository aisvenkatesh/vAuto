﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vAuto
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            //string[] answer = new string[] { "Alpha", "Beta", "Charlie"};
            //string[] answer = new string[] { "Alpha", "Beta", "Charlie", "Delta", "Echo"};
            //string[] answer = new string[] { "Alpha", "Beta", "Charlie", "Delta", "Echo","Foxtrot","Golf","Hotel","Indigo","Juliet" };
            string[] answer = Console.ReadLine().Split(' ').Take(n).ToArray();
            
            Array.Sort(answer);
           
            if (answer.Length == 5)
            {
                string[] newanswer = SwapArrayElement(ref answer[1], ref answer[4]);
                string[] newanswer1 = SwapArrayElement(ref answer[1], ref answer[3]);
                string[] newanswer2 = SwapArrayElement(ref answer[1], ref answer[2]);
                string[] a3 = new string[newanswer.Length + answer.Length];
                
                newanswer.CopyTo(a3, 0);
                answer.CopyTo(a3, newanswer2.Length);
            }
            if(answer.Length==10)
            {
                string[] newanswer = SwapArrayElement(ref answer[1], ref answer[4]);
                string[] newanswer1 = SwapArrayElement(ref answer[2], ref answer[8]);
                string[] newanswer2 = SwapArrayElement(ref answer[1], ref answer[3]);
                string[] newanswer3 = SwapArrayElement(ref answer[3], ref answer[5]);
                string[] newanswer4 = SwapArrayElement(ref answer[3], ref answer[9]);
                string[] newanswer5 = SwapArrayElement(ref answer[2], ref answer[6]);
                string[] newanswer6 = SwapArrayElement(ref answer[6], ref answer[7]);
                string[] newanswer7 = SwapArrayElement(ref answer[3], ref answer[7]);
                string[] a3 = new string[newanswer.Length + answer.Length];
                newanswer.CopyTo(a3, 0);
                answer.CopyTo(a3, newanswer7.Length);
            }
            if (n <= 4)
            {
                Console.WriteLine("The output is "+string.Join(" ", answer));
            }
            else
            {
                int height = (int)Math.Ceiling(answer.Length / (double)4);
                string[,] result = new string[height, 4];
                int rowIndex, colIndex;

                for (int index = 0; index < answer.Length; index++)
                {
                    rowIndex = index / 4;
                    colIndex = index % 4;
                    result[rowIndex, colIndex] = answer[index];
                }
                Console.WriteLine("The output is");
                for (int i = 0; i < height; i++)
                {
                    for (int j = 0; j < 4; j++)
                    {
                        Console.Write(string.Format("{0} ", result[i, j]));
                    }
                    Console.Write(Environment.NewLine + Environment.NewLine);
                }
            }
        }

        public static string[] SwapArrayElement(ref string first, ref string second)
        {
            string temp = first;
            first = second;
            second = temp;
            return new[] {first,second};
        }
    }
}